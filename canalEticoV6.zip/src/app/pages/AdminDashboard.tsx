import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { ArrowLeft, Eye, Download, RefreshCw, Shield, LogOut, Loader2, AlertCircle } from 'lucide-react';
import {
  obtenerDenuncias,
  actualizarEstadoDenuncia,
  actualizarCampoDenuncia,
  Report
} from '../services/api';

export function AdminDashboard() {
  const navigate = useNavigate();
  const [reports, setReports] = useState<Report[]>([]);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [adminUsername, setAdminUsername] = useState('');
  const [adminToken, setAdminToken] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    // Check if user is authenticated
    const isAuthenticated = localStorage.getItem('adminAuth') === 'true';
    const username = localStorage.getItem('adminUsername') || '';
    const token = localStorage.getItem('adminToken') || '';

    if (!isAuthenticated || !token) {
      navigate('/admin');
      return;
    }

    setAdminUsername(username);
    setAdminToken(token);
    loadReports(token);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('adminAuth');
    localStorage.removeItem('adminUsername');
    navigate('/admin');
  };

  const loadReports = async (token: string) => {
    try {
      setLoading(true);
      setError(null);

      const reportsData = await obtenerDenuncias(token);
      setReports(reportsData);
    } catch (err) {
      console.error('Error loading reports:', err);
      setError(
        err instanceof Error
          ? err.message
          : 'No se pudieron cargar las denuncias. Por favor, intenta nuevamente.'
      );
    } finally {
      setLoading(false);
    }
  };

  const changeStatus = async (code: string, newStatus: string) => {
    try {
      setUpdating(true);

      await actualizarEstadoDenuncia(
        code,
        { status: newStatus },
        adminToken
      );

      // Update local state
      const updatedReports = reports.map(report =>
        report.code === code ? { ...report, status: newStatus } : report
      );
      setReports(updatedReports);

      if (selectedReport && selectedReport.code === code) {
        setSelectedReport({ ...selectedReport, status: newStatus });
      }
    } catch (err) {
      console.error('Error updating status:', err);
      alert(
        err instanceof Error
          ? err.message
          : 'No se pudo actualizar el estado. Por favor, intenta nuevamente.'
      );
    } finally {
      setUpdating(false);
    }
  };

  const updateReportField = async (code: string, field: keyof Report, value: string) => {
    try {
      // Update local state immediately for better UX
      const updatedReports = reports.map(report =>
        report.code === code ? { ...report, [field]: value } : report
      );
      setReports(updatedReports);

      if (selectedReport && selectedReport.code === code) {
        setSelectedReport({ ...selectedReport, [field]: value });
      }

      // Debounce API call - only update analysis and conclusion fields
      if (field === 'analysis' || field === 'conclusion') {
        // Call API to update field
        await actualizarCampoDenuncia(
          code,
          { field, value },
          adminToken
        );
      }
    } catch (err) {
      console.error('Error updating field:', err);
      // Optionally, you could revert the local state here or show an error
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Recibida':
        return 'bg-blue-100 text-blue-800';
      case 'En revisión':
        return 'bg-yellow-100 text-yellow-800';
      case 'Cerrada':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredReports = filterStatus === 'all' 
    ? reports 
    : reports.filter(r => r.status === filterStatus);

  return (
    <div className="min-h-screen bg-secondary">
      {/* Header */}
      <div className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8" />
              <div>
                <h1 className="text-2xl">Panel Administrativo</h1>
                <p className="text-sm opacity-90">Canal Ético - Gestión de Denuncias</p>
              </div>
            </div>
            
            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-2 text-primary-foreground hover:underline"
            >
              <ArrowLeft className="w-4 h-4" />
              Salir
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 flex items-start gap-3 mb-6">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-red-800 font-medium">Error</p>
              <p className="text-red-700 text-sm mt-1">{error}</p>
            </div>
          </div>
        )}

        {/* Loading State */}
        {loading ? (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Cargando denuncias...</p>
          </div>
        ) : (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-sm text-muted-foreground mb-2">Total de denuncias</p>
            <p className="text-3xl text-primary">{reports.length}</p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-sm text-muted-foreground mb-2">En revisión</p>
            <p className="text-3xl text-yellow-600">
              {reports.filter(r => r.status === 'En revisión').length}
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-sm text-muted-foreground mb-2">Recibidas</p>
            <p className="text-3xl text-blue-600">
              {reports.filter(r => r.status === 'Recibida').length}
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-lg shadow mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <label className="text-sm text-muted-foreground">Filtrar por estado:</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="all">Todas</option>
              <option value="Recibida">Recibida</option>
              <option value="En revisión">En revisión</option>
              <option value="Cerrada">Cerrada</option>
            </select>
          </div>
          
          <button
            onClick={() => loadReports(adminToken)}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 text-primary hover:bg-secondary rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Actualizar
          </button>
        </div>

        {/* Reports Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-primary text-primary-foreground">
                <tr>
                  <th className="px-6 py-4 text-left">Código</th>
                  <th className="px-6 py-4 text-left">Tipo</th>
                  <th className="px-6 py-4 text-left">Estado</th>
                  <th className="px-6 py-4 text-left">Fecha</th>
                  <th className="px-6 py-4 text-left">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredReports.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-muted-foreground">
                      No hay denuncias registradas
                    </td>
                  </tr>
                ) : (
                  filteredReports.map((report) => (
                    <tr key={report.code} className="hover:bg-secondary transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-mono text-sm">{report.code}</span>
                      </td>
                      <td className="px-6 py-4">{report.type}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(report.status)}`}>
                          {report.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {new Date(report.createdAt).toLocaleDateString('es-ES')}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setSelectedReport(report)}
                            className="p-2 text-primary hover:bg-accent rounded transition-colors"
                            title="Ver detalles"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          
                          {report.fileName && (
                            <button
                              className="p-2 text-primary hover:bg-accent rounded transition-colors"
                              title="Descargar archivo"
                            >
                              <Download className="w-4 h-4" />
                            </button>
                          )}
                          
                          <select
                            value={report.status}
                            onChange={(e) => changeStatus(report.code, e.target.value)}
                            className="ml-2 px-3 py-1 bg-input-background border border-border rounded text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                          >
                            <option value="Recibida">Recibida</option>
                            <option value="En revisión">En revisión</option>
                            <option value="Cerrada">Cerrada</option>
                          </select>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
          </>
        )}
      </div>

      {/* Report Details Modal */}
      {selectedReport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-primary text-primary-foreground p-6 flex items-center justify-between">
              <div>
                <h2 className="text-xl">Detalles de la Denuncia</h2>
                <p className="text-sm opacity-90">{selectedReport.code}</p>
              </div>
              <button
                onClick={() => setSelectedReport(null)}
                className="text-primary-foreground hover:bg-primary-foreground/20 w-8 h-8 rounded transition-colors"
              >
                ✕
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Status */}
              <div>
                <p className="text-sm text-muted-foreground mb-1">Estado</p>
                <span className={`inline-block px-4 py-2 rounded-full ${getStatusColor(selectedReport.status)}`}>
                  {selectedReport.status}
                </span>
              </div>

              {/* Company and Department Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Empresa</p>
                  <p className="text-foreground">{selectedReport.empresa}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Departamento</p>
                  <p className="text-foreground">{selectedReport.departamento}</p>
                </div>
              </div>

              {/* Report Type */}
              <div>
                <p className="text-sm text-muted-foreground mb-1">Tipo de denuncia</p>
                <p className="text-foreground">{selectedReport.type}</p>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Fecha del incidente</p>
                  <p className="text-foreground">
                    {new Date(selectedReport.date).toLocaleDateString('es-ES', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Fecha de creación</p>
                  <p className="text-foreground">
                    {new Date(selectedReport.createdAt).toLocaleDateString('es-ES', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
              </div>

              {/* Complainant Info */}
              <div className="border-t border-border pt-4">
                <h3 className="text-sm mb-3">Información del Denunciante</h3>
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Nombre</p>
                    <p className="text-foreground">{selectedReport.nombreDenunciante}</p>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Email</p>
                      <p className="text-foreground text-sm">{selectedReport.emailDenunciante}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Teléfono</p>
                      <p className="text-foreground">{selectedReport.telefonoDenunciante}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="border-t border-border pt-4">
                <p className="text-sm text-muted-foreground mb-2">Descripción de la denuncia</p>
                <div className="bg-secondary p-4 rounded-lg">
                  <p className="text-foreground whitespace-pre-wrap">{selectedReport.description}</p>
                </div>
              </div>

              {/* Involved Persons */}
              {selectedReport.involved && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Personas involucradas</p>
                  <div className="bg-secondary p-4 rounded-lg">
                    <p className="text-foreground">{selectedReport.involved}</p>
                  </div>
                </div>
              )}

              {/* Witnesses */}
              {selectedReport.testigos && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Testigos</p>
                  <div className="bg-secondary p-4 rounded-lg">
                    <p className="text-foreground">{selectedReport.testigos}</p>
                  </div>
                </div>
              )}

              {/* Attached File */}
              {selectedReport.fileName && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Archivo adjunto</p>
                  <div className="bg-secondary p-4 rounded-lg flex items-center justify-between">
                    <p className="text-foreground">{selectedReport.fileName}</p>
                    <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded hover:bg-primary/90 transition-colors">
                      <Download className="w-4 h-4" />
                      Descargar
                    </button>
                  </div>
                </div>
              )}

              {/* Analysis Section */}
              <div className="border-t border-border pt-4">
                <label className="text-sm text-muted-foreground mb-2 block">Análisis del caso</label>
                <textarea
                  value={selectedReport.analysis}
                  onChange={(e) => updateReportField(selectedReport.code, 'analysis', e.target.value)}
                  placeholder="Escriba aquí el análisis detallado del caso..."
                  className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary min-h-[120px] resize-y"
                />
              </div>

              {/* Conclusion Section */}
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Conclusión y medidas tomadas</label>
                <textarea
                  value={selectedReport.conclusion}
                  onChange={(e) => updateReportField(selectedReport.code, 'conclusion', e.target.value)}
                  placeholder="Escriba aquí la conclusión y las medidas adoptadas..."
                  className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary min-h-[120px] resize-y"
                />
              </div>

              {/* Change Status */}
              <div className="pt-6 border-t border-border">
                <p className="text-sm text-muted-foreground mb-2">Cambiar estado</p>
                <select
                  value={selectedReport.status}
                  onChange={(e) => changeStatus(selectedReport.code, e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="Recibida">Recibida</option>
                  <option value="En revisión">En revisión</option>
                  <option value="Cerrada">Cerrada</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}