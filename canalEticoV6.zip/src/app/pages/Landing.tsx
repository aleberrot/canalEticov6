import { Shield } from 'lucide-react';
import { Link } from 'react-router';

export function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary to-white">
      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="flex flex-col items-center justify-center min-h-[80vh] text-center">
          <div className="mb-8 bg-primary rounded-full p-6 shadow-lg">
            <Shield className="w-16 h-16 text-primary-foreground" />
          </div>
          
          <h1 className="mb-6 text-5xl text-primary">Canal Ético</h1>
          
          <p className="mb-4 text-xl text-foreground max-w-2xl leading-relaxed">
            Canal seguro y confidencial para reportar acoso laboral, acoso sexual, 
            violencia o conductas inapropiadas en el lugar de trabajo.
          </p>
          
          <p className="mb-12 text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Tu reporte será tratado de manera <strong>anónima</strong> y <strong>confidencial</strong>, 
            conforme a la Ley Karin y las normativas vigentes de protección laboral.
          </p>
          
          <div className="flex flex-col gap-4 w-full max-w-lg">
            <Link 
              to="/submit"
              className="bg-primary text-primary-foreground py-4 px-8 rounded-lg hover:bg-primary/90 transition-colors shadow-md text-center"
            >
              Enviar denuncia
            </Link>
            
            <Link 
              to="/tracking"
              className="bg-white text-primary py-4 px-8 rounded-lg border-2 border-primary hover:bg-secondary transition-colors shadow-md text-center"
            >
              Consultar denuncia
            </Link>
            
            <Link 
              to="/ley-karin"
              className="bg-accent text-primary py-4 px-8 rounded-lg border border-primary/30 hover:border-primary hover:bg-accent/70 transition-colors shadow-sm text-center"
            >
              Ley Karin – Información
            </Link>
          </div>
          
          <div className="mt-12 text-sm text-muted-foreground">
            <Link 
              to="/admin"
              className="hover:text-primary transition-colors underline"
            >
              Acceso administrativo
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}