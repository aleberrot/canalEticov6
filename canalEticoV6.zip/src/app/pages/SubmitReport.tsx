import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { ArrowLeft, Upload, CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import { SimpleCaptcha } from '../components/SimpleCaptcha';
import { crearDenuncia } from '../services/api';

export function SubmitReport() {
  const navigate = useNavigate();
  const [submitted, setSubmitted] = useState(false);
  const [reportCode, setReportCode] = useState('');
  const [captchaVerified, setCaptchaVerified] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    type: '',
    description: '',
    involved: '',
    date: '',
    password: '',
    file: null as File | null,
    acceptTruth: false,
    acceptLeyKarin: false,
    empresa: '',
    departamento: '',
    nombreDenunciante: '',
    emailDenunciante: '',
    telefonoDenunciante: '',
    testigos: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate checkboxes
    if (!formData.acceptTruth || !formData.acceptLeyKarin) {
      setError('Debes aceptar las declaraciones requeridas para continuar.');
      return;
    }

    // Validate captcha
    if (!captchaVerified) {
      setError('Por favor, completa la verificación de seguridad.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Prepare data for API
      const reportData = {
        type: formData.type,
        description: formData.description,
        involved: formData.involved || '',
        date: formData.date,
        password: formData.password,
        empresa: formData.empresa,
        departamento: formData.departamento,
        nombreDenunciante: formData.nombreDenunciante || 'Anónimo',
        emailDenunciante: formData.emailDenunciante || 'no-proporcionado@anonimo.cl',
        telefonoDenunciante: formData.telefonoDenunciante || 'No proporcionado',
        testigos: formData.testigos || '',
        fileName: formData.file?.name || null
      };

      // Call API to create report
      const result = await crearDenuncia(reportData);

      if (result.success && result.code) {
        setReportCode(result.code);
        setSubmitted(true);
      } else {
        throw new Error(result.message || 'Error al crear la denuncia');
      }
    } catch (err) {
      console.error('Error submitting report:', err);
      setError(
        err instanceof Error
          ? err.message
          : 'No se pudo enviar la denuncia. Por favor, intenta nuevamente.'
      );
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-secondary to-white py-12">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="flex justify-center mb-6">
              <CheckCircle className="w-20 h-20 text-green-600" />
            </div>
            
            <h1 className="mb-4 text-primary">Denuncia Enviada Correctamente</h1>
            
            <p className="mb-6 text-muted-foreground leading-relaxed">
              Tu denuncia fue enviada correctamente. Guarda tu código de seguimiento 
              para consultar el estado.
            </p>
            
            <div className="bg-gradient-to-br from-primary to-primary/80 p-8 rounded-lg mb-8 shadow-lg">
              <p className="text-sm text-primary-foreground/90 mb-3 uppercase tracking-wide">
                Código de seguimiento
              </p>
              <p className="text-4xl md:text-5xl text-primary-foreground tracking-wider mb-2">
                {reportCode}
              </p>
              <p className="text-xs text-primary-foreground/80 mt-2">
                Guarda este código en un lugar seguro
              </p>
            </div>
            
            <div className="bg-accent border-2 border-primary/30 p-5 rounded-lg mb-8">
              <p className="text-sm text-primary leading-relaxed">
                <strong>Importante:</strong> Guarda este código y la contraseña que proporcionaste 
                para poder consultar el estado de tu denuncia. Tu reporte será procesado de manera 
                confidencial conforme a la Ley Karin.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/"
                className="flex-1 bg-white text-primary py-3 px-6 rounded-lg border-2 border-primary hover:bg-secondary transition-colors"
              >
                Volver al inicio
              </Link>
              
              <button
                onClick={() => navigate('/tracking')}
                className="flex-1 bg-primary text-primary-foreground py-3 px-6 rounded-lg hover:bg-primary/90 transition-colors"
              >
                Consultar estado
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary to-white py-12">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link 
          to="/"
          className="inline-flex items-center gap-2 text-primary hover:underline mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Volver al inicio
        </Link>
        
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="mb-2 text-primary">Enviar Denuncia</h1>
          <p className="mb-8 text-muted-foreground leading-relaxed">
            Completa el formulario con la mayor información posible. Todos los datos son confidenciales 
            y serán tratados conforme a la Ley Karin.
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Error Message */}
            {error && (
              <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-red-800 font-medium">Error</p>
                  <p className="text-red-700 text-sm mt-1">{error}</p>
                </div>
              </div>
            )}

            {/* Company and Department Info */}
            <div className="border-b border-border pb-6">
              <h3 className="text-primary mb-4">Información de la empresa</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="empresa" className="block mb-2 text-foreground">
                    Empresa *
                  </label>
                  <input
                    id="empresa"
                    type="text"
                    required
                    value={formData.empresa}
                    onChange={(e) => setFormData({ ...formData, empresa: e.target.value })}
                    placeholder="Nombre de la empresa"
                    className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label htmlFor="departamento" className="block mb-2 text-foreground">
                    Departamento *
                  </label>
                  <input
                    id="departamento"
                    type="text"
                    required
                    value={formData.departamento}
                    onChange={(e) => setFormData({ ...formData, departamento: e.target.value })}
                    placeholder="Área o departamento"
                    className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>
            </div>

            {/* Complainant Info */}
            <div className="border-b border-border pb-6">
              <h3 className="text-primary mb-2">Información del denunciante (opcional)</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Puedes realizar tu denuncia de forma anónima. Si prefieres proporcionar tus datos, te permitirá un mejor seguimiento.
              </p>
              <div className="space-y-4">
                <div>
                  <label htmlFor="nombreDenunciante" className="block mb-2 text-foreground">
                    Nombre completo
                  </label>
                  <input
                    id="nombreDenunciante"
                    type="text"
                    value={formData.nombreDenunciante}
                    onChange={(e) => setFormData({ ...formData, nombreDenunciante: e.target.value })}
                    placeholder="Tu nombre (opcional)"
                    className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="emailDenunciante" className="block mb-2 text-foreground">
                      Email de contacto
                    </label>
                    <input
                      id="emailDenunciante"
                      type="email"
                      value={formData.emailDenunciante}
                      onChange={(e) => setFormData({ ...formData, emailDenunciante: e.target.value })}
                      placeholder="correo@ejemplo.com"
                      className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label htmlFor="telefonoDenunciante" className="block mb-2 text-foreground">
                      Teléfono de contacto
                    </label>
                    <input
                      id="telefonoDenunciante"
                      type="tel"
                      value={formData.telefonoDenunciante}
                      onChange={(e) => setFormData({ ...formData, telefonoDenunciante: e.target.value })}
                      placeholder="+56 9 XXXX XXXX"
                      className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Report Type */}
            <div>
              <label htmlFor="type" className="block mb-2 text-foreground">
                Tipo de denuncia *
              </label>
              <select
                id="type"
                required
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">Selecciona un tipo</option>
                <option value="Acoso laboral">Acoso laboral</option>
                <option value="Acoso sexual">Acoso sexual</option>
                <option value="Violencia en el trabajo">Violencia en el trabajo</option>
                <option value="Discriminación">Discriminación</option>
                <option value="Conflicto de interés">Conflicto de interés</option>
                <option value="Fraude">Fraude</option>
                <option value="Violación de políticas">Violación de políticas</option>
                <option value="Otros">Otros</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="description" className="block mb-2 text-foreground">
                Descripción detallada *
              </label>
              <textarea
                id="description"
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={6}
                placeholder="Describe lo sucedido con el mayor detalle posible..."
                className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              />
            </div>
            
            <div>
              <label htmlFor="involved" className="block mb-2 text-foreground">
                Personas involucradas
              </label>
              <input
                id="involved"
                type="text"
                value={formData.involved}
                onChange={(e) => setFormData({ ...formData, involved: e.target.value })}
                placeholder="Nombres o cargos (opcional)"
                className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div>
              <label htmlFor="testigos" className="block mb-2 text-foreground">
                Testigos
              </label>
              <input
                id="testigos"
                type="text"
                value={formData.testigos}
                onChange={(e) => setFormData({ ...formData, testigos: e.target.value })}
                placeholder="Nombres de testigos o evidencias (opcional)"
                className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            
            <div>
              <label htmlFor="date" className="block mb-2 text-foreground">
                Fecha del incidente *
              </label>
              <input
                id="date"
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            
            <div>
              <label htmlFor="file" className="block mb-2 text-foreground">
                Adjuntar archivo
              </label>
              <div className="relative">
                <input
                  id="file"
                  type="file"
                  onChange={(e) => setFormData({ ...formData, file: e.target.files?.[0] || null })}
                  className="hidden"
                />
                <label
                  htmlFor="file"
                  className="flex items-center gap-3 w-full px-4 py-3 bg-input-background border border-border rounded-lg cursor-pointer hover:bg-secondary transition-colors"
                >
                  <Upload className="w-5 h-5 text-muted-foreground" />
                  <span className="text-muted-foreground">
                    {formData.file ? formData.file.name : 'Seleccionar archivo (opcional)'}
                  </span>
                </label>
              </div>
            </div>
            
            <div className="border-t border-border pt-6">
              <label htmlFor="password" className="block mb-2 text-foreground">
                Contraseña para seguimiento *
              </label>
              <input
                id="password"
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="Crea una contraseña segura"
                className="w-full px-4 py-3 bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <p className="mt-2 text-sm text-muted-foreground">
                Necesitarás esta contraseña para consultar el estado de tu denuncia.
              </p>
            </div>
            
            {/* Compliance Section */}
            <div className="border-t border-border pt-6 space-y-4">
              <h3 className="text-primary mb-4">Declaraciones requeridas</h3>
              
              <div className="flex items-start gap-3 p-4 bg-secondary rounded-lg">
                <input
                  type="checkbox"
                  id="acceptTruth"
                  checked={formData.acceptTruth}
                  onChange={(e) => setFormData({ ...formData, acceptTruth: e.target.checked })}
                  className="mt-1 w-5 h-5 text-primary border-border rounded focus:ring-2 focus:ring-primary cursor-pointer"
                  required
                />
                <label htmlFor="acceptTruth" className="text-foreground cursor-pointer leading-relaxed">
                  Declaro que la información entregada es verídica y realizada de buena fe.
                </label>
              </div>
              
              <div className="flex items-start gap-3 p-4 bg-secondary rounded-lg">
                <input
                  type="checkbox"
                  id="acceptLeyKarin"
                  checked={formData.acceptLeyKarin}
                  onChange={(e) => setFormData({ ...formData, acceptLeyKarin: e.target.checked })}
                  className="mt-1 w-5 h-5 text-primary border-border rounded focus:ring-2 focus:ring-primary cursor-pointer"
                  required
                />
                <label htmlFor="acceptLeyKarin" className="text-foreground cursor-pointer leading-relaxed">
                  He leído la información relacionada con la Ley Karin y el uso responsable de este canal.
                  {' '}
                  <Link to="/ley-karin" className="text-primary underline hover:text-primary/80">
                    (Ver información)
                  </Link>
                </label>
              </div>
            </div>
            
            {/* Captcha */}
            <div className="border-t border-border pt-6">
              <SimpleCaptcha onVerify={setCaptchaVerified} />
            </div>
            
            <button
              type="submit"
              disabled={!formData.acceptTruth || !formData.acceptLeyKarin || !captchaVerified || loading}
              className="w-full bg-primary text-primary-foreground py-4 rounded-lg hover:bg-primary/90 transition-colors shadow-md disabled:bg-muted disabled:text-muted-foreground disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Enviando...
                </>
              ) : (
                'Enviar denuncia'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}