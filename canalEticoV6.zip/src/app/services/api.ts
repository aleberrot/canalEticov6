// Centralized API service for backend communication
export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';

// Types
export interface CreateReportRequest {
  type: string;
  description: string;
  involved: string;
  date: string;
  password: string;
  empresa: string;
  departamento: string;
  nombreDenunciante?: string;
  emailDenunciante?: string;
  telefonoDenunciante?: string;
  testigos?: string;
  fileName?: string | null;
}

export interface Report {
  code: string;
  type: string;
  description: string;
  involved: string;
  date: string;
  status: string;
  createdAt: string;
  fileName: string | null;
  password: string;
  empresa: string;
  departamento: string;
  nombreDenunciante: string;
  emailDenunciante: string;
  telefonoDenunciante: string;
  testigos: string;
  analysis: string;
  conclusion: string;
}

export interface TrackReportRequest {
  code: string;
  password: string;
}

export interface AdminLoginRequest {
  username: string;
  password: string;
}

export interface AdminLoginResponse {
  success: boolean;
  token?: string;
  username?: string;
  message?: string;
}

export interface UpdateReportStatusRequest {
  status: string;
}

export interface UpdateReportFieldRequest {
  field: string;
  value: string;
}

// API Methods

/**
 * Create a new report (denuncia)
 */
export const crearDenuncia = async (data: CreateReportRequest): Promise<{ success: boolean; code: string; message?: string }> => {
  try {
    const response = await fetch(`${API_URL}/api/denuncias`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || 'Error al enviar la denuncia');
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error creating report:', error);
    throw error;
  }
};

/**
 * Track a report by code and password
 */
export const consultarDenuncia = async (data: TrackReportRequest): Promise<Report> => {
  try {
    const response = await fetch(`${API_URL}/api/denuncias/consultar`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || 'No se pudo encontrar la denuncia');
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error fetching report:', error);
    throw error;
  }
};

/**
 * Admin login
 */
export const adminLogin = async (data: AdminLoginRequest): Promise<AdminLoginResponse> => {
  try {
    const response = await fetch(`${API_URL}/api/admin/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || 'Error de autenticación');
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error logging in:', error);
    throw error;
  }
};

/**
 * Get all reports (admin)
 */
export const obtenerDenuncias = async (token: string): Promise<Report[]> => {
  try {
    const response = await fetch(`${API_URL}/api/admin/denuncias`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || 'Error al obtener denuncias');
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error fetching reports:', error);
    throw error;
  }
};

/**
 * Update report status (admin)
 */
export const actualizarEstadoDenuncia = async (
  code: string,
  data: UpdateReportStatusRequest,
  token: string
): Promise<{ success: boolean; message?: string }> => {
  try {
    const response = await fetch(`${API_URL}/api/admin/denuncias/${code}/estado`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || 'Error al actualizar el estado');
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error updating report status:', error);
    throw error;
  }
};

/**
 * Update report field (admin) - for analysis and conclusion
 */
export const actualizarCampoDenuncia = async (
  code: string,
  data: UpdateReportFieldRequest,
  token: string
): Promise<{ success: boolean; message?: string }> => {
  try {
    const response = await fetch(`${API_URL}/api/admin/denuncias/${code}/campo`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || 'Error al actualizar el campo');
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error updating report field:', error);
    throw error;
  }
};
