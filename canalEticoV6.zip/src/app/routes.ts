import { createBrowserRouter } from 'react-router';
import { Landing } from './pages/Landing';
import { SubmitReport } from './pages/SubmitReport';
import { Tracking } from './pages/Tracking';
import { ReportStatus } from './pages/ReportStatus';
import { AdminDashboard } from './pages/AdminDashboard';
import { AdminLogin } from './pages/AdminLogin';
import { LeyKarinInfo } from './pages/LeyKarinInfo';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Landing,
  },
  {
    path: '/submit',
    Component: SubmitReport,
  },
  {
    path: '/tracking',
    Component: Tracking,
  },
  {
    path: '/status/:code',
    Component: ReportStatus,
  },
  {
    path: '/admin',
    Component: AdminLogin,
  },
  {
    path: '/admin/dashboard',
    Component: AdminDashboard,
  },
  {
    path: '/ley-karin',
    Component: LeyKarinInfo,
  },
]);